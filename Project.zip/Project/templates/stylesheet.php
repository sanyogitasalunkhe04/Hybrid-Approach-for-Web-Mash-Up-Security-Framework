<link href="<?php echo DOMAIN; ?>/css/bootstrap.css" rel="stylesheet" media="screen"> 
<link href="<?php echo DOMAIN; ?>/css/bootstrap-responsive.css" rel="stylesheet">
<link href="<?php echo DOMAIN; ?>/css/style.css" rel="stylesheet">
<link href="<?php echo DOMAIN; ?>/css/camera.css" rel="stylesheet">
<link href="<?php echo DOMAIN; ?>/css/font-awesome.css" rel="stylesheet">
<!--[if IE 7]>
<link rel="stylesheet" href="../css/font-awesome-ie7.min.css">
<![endif]-->

