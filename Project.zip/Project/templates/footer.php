
<div style="background: #FE642E; border-top: 2px solid #FFF; margin-top: 20px;">
	<div class="row-fluid grid_960_system">
		<div class="row-fluid">
			<div class="span12">
				<ul class="inline pull-right" style="font-weight: bold; margin-top: 5px;">
					<li><a style="color: #FFF;" href="<?php echo DOMAIN; ?>/index.php">Home</a>&nbsp;&nbsp;|</li>
					<li><a style="color: #FFF;" href="<?php echo DOMAIN; ?>/includes/about_project.php">About Project</a>&nbsp;&nbsp;|</li>
					<li><a style="color: #FFF;" href="<?php echo DOMAIN; ?>/includes/contact_us.php">Contact Us</a></li>
				</ul>
			</div>
		</div>
		<div class="row-fluid">
			<div class="span12">
				<p style="color: #FFF; font-size: 15px;">A web mashup is a web application that integrates content from different providers to create a new service, not offered by the content providers. As mashups grow in popularity, the problem of securing information flow between mashup components becomes increasingly important. This application presents a security approach to mashup security, where the origins of the different components of the mashup are used as levels in the security. </p>
			</div>
		</div>
		<div class="row-fluid" style="margin-top: 10px;">
			<div class="span12 nav-header">
				<center><span style="color: #FFF;">Hybrid Approach for Web Mash Up Security&copy; 2014 </span></center>
			</div>
		</div>
	</div>
</div>


