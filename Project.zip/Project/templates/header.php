<div class="row-fluid">
	<div class="navbar navbar-fluid-top">
		<div class="navbar-inner">
		<div class="container-fluid">
		  <a class="btn btn-navbar" data-target=".nav-collapse" data-toggle="collapse">
		    <span class="icon-bar"></span>
		    <span class="icon-bar"></span>
		    <span class="icon-bar"></span>
		  </a>
		  <a class="brand" href="<?php echo DOMAIN; ?>/index.php">Hybrid Approach for Web Mash Up Security Framework</a>
		  <div class="container-fluid nav-collapse">
		    <ul class="nav">
		      <li><a href="<?php echo DOMAIN; ?>/index.php">&nbsp;Home</a></li>
		      <li><a href="<?php echo DOMAIN; ?>/includes/about_project.php">About project</a></li>
		      <?php if(!isset($_SESSION['user_id'])) { ?>
		      <li><a href="<?php echo DOMAIN; ?>/user_panel/index.php">Log In</a></li>
		      <?php 
			} 
			else
			{
		      ?>
		      <li><a href="<?php echo DOMAIN; ?>/user_panel/dashboard.php">Dashboard</a></li>
		      <li><a href="<?php echo DOMAIN; ?>/user_panel/books/index.php">Book</a></li>
		      <li><a href="<?php echo DOMAIN; ?>/user_panel/news/index.php">News</a></li>
		      <?php } ?>
		    </ul>
		  </div><!--/.nav-collapse -->
		</div>
	      </div>
	</div>
</div>
