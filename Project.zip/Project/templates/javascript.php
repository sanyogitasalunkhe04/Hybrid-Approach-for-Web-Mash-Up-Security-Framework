<script type='text/javascript' src="<?php echo DOMAIN; ?>/js/jquery-1.8.3.js"></script>
<script type='text/javascript' src="<?php echo DOMAIN; ?>/js/bootstrap.min.js"></script>
<script type='text/javascript' src="<?php echo DOMAIN; ?>/js/bootstrap-modal.js"></script>
<script type='text/javascript' src="<?php echo DOMAIN; ?>/js/jquery.easing.1.3.js"></script> 
<script type="text/javascript" src="<?php echo DOMAIN; ?>/js/jquery.validate1.9.0.js"></script>
<script type="text/javascript" src="<?php echo DOMAIN; ?>/js/form_validation.js"></script>
<script type="text/javascript" src="<?php echo DOMAIN; ?>/js/hoverintent.js"></script>
<script type="text/javascript" src="<?php echo DOMAIN; ?>/js/camera.min.js"></script>
<script type="text/javascript" src="<?php echo DOMAIN; ?>/js/menu.js"></script>


