<?php require_once('../configuration.php'); ?>
<span style="color: #444444; font-size: 35px; font-family: Georgia">
	<h3>Hybrid Approach for Web Mash Up Security</h3>
</span>
<p>Click below link....</p>
<a href="<?php echo DOMAIN; ?>/home.php" target="_blank">Home Page</a>
