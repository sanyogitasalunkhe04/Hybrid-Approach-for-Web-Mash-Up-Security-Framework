<?php require_once('../configuration.php'); ?>
<frameset cols="*, *, *">
	<frame src="gmail.html" scrolling="no" noresize="noresize"></frame>
	<frame src="http://www.w3schools.com/" scrolling="yes" noresize="noresize"></frame>
	<frame src="http://www.bbc.com/news/" scrolling="yes" noresize="noresize"></frame>
</frameset>
