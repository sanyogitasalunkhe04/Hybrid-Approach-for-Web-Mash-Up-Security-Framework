<?php require_once('../configuration.php'); ?>
<frameset cols="*, *, *">
	<frame src="<?php echo DOMAIN; ?>/frames/main_site.php" scrolling="no" noresize="noresize"></frame>
	<frame src="http://www.espncricinfo.com/" scrolling="no" noresize="noresize"></frame>
	<frame src="<?php echo DOMAIN; ?>/frames/fb.html" scrolling="no" noresize="noresize"></frame>
</frameset>
